<?php

#Lab Assignment 8
#
#File Name: Richard_Carmona_Lab8.php
#Title of File: Report Errors
#Created By: Richard Carmona	
#Created Date: 11/28/2018	
#Description: This will use a costom error handler to handle errors

#########################################################
#########################################################
#Task 1: CREATE A CUSTOM ERROR HANDLER DISPLAYING ERROR IN ANY WAY YOU WISH.
#		 USE FUNCTION BELOW (report_errors) 
#########################################################
#########################################################

define('LIVE', FALSE);



function report_errors($e_num, $e_message, $e_file, $e_line, $e_vars){
	
	
	$error_message = "There is an error on this file '$e_file' on line
						'$e_line' : $e_message\n";
	
	$error_message .= print_r($e_vars,1);


					if(!LIVE) {
						echo $message. "\n"
						debug_print_backtrace();	
					}	else{
						echo '<div class="error">
						ERROR!!!
						Try again your script contains errors.'
						
						
					}
	
	
}

##############
#Uncomment this set_error_handler function call after completing report_errors function (Task 1)
##############

set_error_handler('report_errors');

#########################################################
#########################################################
# Task 2A: SUPPRESS THE ERROR FOR INCLUDING THIS INCORRECT PATH
#########################################################
#########################################################
@include("/incorrect/path/navbar.php");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Lab 8 - Form</title>
</head>

<body>

    <?php
	#########################################################
	#########################################################
	#Task 3: Modify the action attribute below so that the url contains
	#		 a variable name called "location" with value of "Norco"
	#########################################################
	#########################################################
	?>
    <form action="lab8.php" method="post">

        <p><label>Item Name: <input type="text" name="item_name" size="40" maxlength="60" value="<?php
		
			if (!empty($_POST['item_name'])) echo $_POST['item_name'];
            
		$location='NORCO';
            
		?>"></label></p>
        
        <p><label>Store:
                <select name="store">
                    <option value="ralphs" <?php if (isset($_POST['store']) && $_POST['store']=="ralphs" ) echo "selected" ?> >Ralphs</option>
                    <option value="vons" <?php if (isset($_POST['store']) && $_POST['store']=="vons" ) echo "selected" ?> >Vons</option>
                    <option value="whole_foods" <?php if (isset($_POST['store']) && $_POST['store']=="whole_foods" ) echo "selected" ?> >Whole Foods</option>
                    <input type="hidden" name="id" value="'.$id.'">

                </select></label></p>

        <p><label>Total Cost: <input type="number" name="price" step="0.01" value="<?php
		
			if (isset($_POST['price'])) echo $_POST['price'];
			
		?>"></label></p>

        <p><label>Quantity: <input type="number" name="quantity" step="1" value="<?php
		
			if (isset($_POST['quantity'])) echo $_POST['quantity'];
			
		?>"></label></p>

        <p align="left"><input type="submit" name="submit" value="Submit"></p>

    </form>

    <?php
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			
			if (!empty($_POST['item_name'])){
				$name = $_POST['item_name'];
			}
			else{
				$name = NULL;
				echo "<br>Error in 'Item Name' field.";
			}
			
			if (isset($_POST['store'])){
				$store = $_POST['store'];
			}
			else{
				$store = NULL;
				echo "<br>Error in 'Store' field.";
			}
			
			if (isset($_POST['price']) && is_numeric($_POST['price'])){
				$price = $_POST['price'];
			}
			else{
				$price = NULL;
				echo "<br>Error in 'Price' field.";
			}
			
			if (isset($_POST['quantity']) && is_numeric($_POST['quantity'])){
				$quantity = $_POST['quantity'];
			}
			else{
				$quantity = NULL;
				echo "<br>Error in 'Quantity' field.";
			}
			
			if (($name && $store && $price) && ($quantity >= 0)){
				###########################################################
				###########################################################
				#Task 2B: 
				#If Quantity is 0, this will throw an error.              
				#SUPPRESS ERROR WHEN DIVIDING ($price/$quantity)
				###########################################################
				###########################################################
				$unitcost = $price / $quantity;
				
				@if ($quantity == 0){
					echo "<p>Quantity must be greater than zero to calculate cost per item.</p>";
				}
				else{
					$unitcost_dollar = "$" . number_format($unitcost,2);
					echo "<p>$name from $store will cost $unitcost_dollar per item.</p>";
				} 
			}
			else{
				echo "<p>Please correct errors before the cost per item can be calculated.</p>";
			}
		}
		
		#Display location
		if (isset($_GET['location'])){
			echo "Location of Store: " . $_GET['location'] . "<br>";
		}
		else{
			echo "Location of Store: Not Yet Set<br>";
		}
		
		######################
		######################
		#Do NOT supress this error
		#This should generate an error using error message created in "report_errors" function
		foreach($array_var as $val){
			echo "<br>$val";
		}
	?>


</body>

</html>
