<?php
include('includes/header.html');
include('includes/footer.html');

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
	$errors =[];

	if(empty($_POST['username'])){
		$errors[]='You need a username to register';	
		}
	else{
		$un=trim($_POST['username']);
		
	}

	if(empty($_POST['firstname'])){
		$errors[]='Please re-enter your name';
	}
	else{
		$fn=trim($_POST['firstname']);
	}

	
	if(empty($_POST['lastname'])){
		$errors[]='Re-enter your last name';
	}
	else{
		$ln=trim($_POST['lastname']);
		
	}
	
	if(empty($_POST['email'])){
		$errors[]= 'What is your email?';
	}
	else{
		$em=trim($_POST['email']);
	}
	
	if(!empty($_POST['password'])){
		if($_POST['password'] != $_POST['cofirmpass'])
		{
			$errors[]='Passwords do not match.';
		}
		
		else{
			$pw=trim($_POST['password']);
		}
		
	}
	else{
		$errors[]='Please enter a password';
	}
	
	
	
	
	
 ?>





<body>

    <h1>User Sign In/Up </br> </br>

    </h1>


    <fieldset>
        <legend> User Registration </legend>
        <form action="user.php" method="post">


            USERNAME:

            <input type=text name="username" size="15" maxlength="20" value="<?php
if(isset($_POST['username'])) echo $_POST['username']; ?>"> </br></br>


            Email:

            <input type=text name="email" size="20" maxlength="60" value="<?php
  if(isset($_POST['email'])) echo $_POST['email']; ?>"> </br></br>


            PASSWORD:

            <input type=text name="password" size="15" maxlength="20" value="<?php
  if(isset($_POST['password'])) echo $_POST['password'];?>"></br></br>

            CONFIRM PASSWORD:

            <input type=text name="confirmpass" size="15" maxlength="20" value="<?php
  if(isset($_POST['confirmpass'])) echo $_POST['confirmpass'];?>"></br></br>

            <input type="submit" value="submit">
        </form>
    </fieldset>
</body>
