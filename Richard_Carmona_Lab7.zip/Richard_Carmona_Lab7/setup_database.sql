-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE DATABASE `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Product` (
  `productid` INT NOT NULL,
  `shutters` VARCHAR(45) NULL,
  `blinds` VARCHAR(45) NULL,
  `shades` VARCHAR(45) NULL,
  PRIMARY KEY (`productid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`user` (
  `username` VARCHAR(16) NOT NULL,
  `email` VARCHAR(255) NULL,
  `password` VARCHAR(32) NOT NULL,
  `create_time` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`username`));


-- -----------------------------------------------------
-- Table `mydb`.`Purchase`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Purchase` (
  `idPurchase` INT NOT NULL,
  `user_acount_id` VARCHAR(45) NULL,
  `user_username` VARCHAR(16) NOT NULL,
  PRIMARY KEY (`idPurchase`),
  INDEX `fk_Purchase_user_idx` (`user_username` ASC) VISIBLE,
  CONSTRAINT `fk_Purchase_user`
    FOREIGN KEY (`user_username`)
    REFERENCES `mydb`.`user` (`username`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`purchase_item`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`purchase_item` (
  `idpurchase_item` INT NOT NULL,
  `productid` VARCHAR(45) NULL,
  `number_of_items` VARCHAR(45) NULL,
  `total_price` VARCHAR(45) NULL,
  `Purchase_idPurchase` INT NOT NULL,
  `Product_productid` INT NOT NULL,
  PRIMARY KEY (`idpurchase_item`),
  INDEX `fk_purchase_item_Purchase1_idx` (`Purchase_idPurchase` ASC) VISIBLE,
  INDEX `fk_purchase_item_Product1_idx` (`Product_productid` ASC) VISIBLE,
  CONSTRAINT `fk_purchase_item_Purchase1`
    FOREIGN KEY (`Purchase_idPurchase`)
    REFERENCES `mydb`.`Purchase` (`idPurchase`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_purchase_item_Product1`
    FOREIGN KEY (`Product_productid`)
    REFERENCES `mydb`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;